DROP SCHEMA IF EXISTS cc_user CASCADE;
CREATE SCHEMA cc_user;
SET search_path = cc_user;

-- Crear tablas con todas las restricciones desde el inicio
CREATE TABLE cc_user.manufacturers (
    id integer PRIMARY KEY,
    name varchar NOT NULL
);

CREATE TABLE cc_user.parts (
    id integer PRIMARY KEY,
    description character varying NOT NULL,
    code character varying NOT NULL UNIQUE,
    manufacturer_id integer NOT NULL REFERENCES manufacturers(id)
);

CREATE TABLE cc_user.reorder_options (
    id integer PRIMARY KEY,
    part_id integer NOT NULL REFERENCES parts(id),
    price_usd numeric(8,2) NOT NULL CHECK (price_usd > 0),
    quantity integer NOT NULL CHECK (quantity > 0),
    CHECK (price_usd/quantity BETWEEN 0.02 AND 25.00)
);

CREATE TABLE cc_user.locations (
    id integer PRIMARY KEY,
    part_id integer NOT NULL REFERENCES parts(id),
    location varchar(3) NOT NULL,
    qty integer NOT NULL CHECK (qty > 0),
    UNIQUE(part_id, location)
);

-- Cargar datos
COPY cc_user.manufacturers FROM 'manufacturers.csv' delimiter ',' NULL AS 'NULL' csv header

-- Primero cargar partes sin la restricción de manufacturer_id
CREATE TEMPORARY TABLE temp_parts (
    id integer,
    description character varying,
    code character varying,
    manufacturer_id integer
);

\copy temp_parts FROM 'parts.csv' delimiter ',' NULL AS 'NULL' csv header

-- Insertar en la tabla real con descripción no nula
INSERT INTO cc_user.parts (id, description, code, manufacturer_id)
SELECT 
    id, 
    COALESCE(description, 'Sin descripción disponible') as description,
    code,
    manufacturer_id
FROM temp_parts;

DROP TABLE temp_parts;

\copy cc_user.locations FROM 'locations.csv' delimiter ',' NULL AS 'NULL' csv header
\copy cc_user.reorder_options FROM 'reorder_options.csv' delimiter ',' NULL AS 'NULL' csv header

-- Procesar la fusión de fabricantes (Pip Industrial y NNC Manufacturing)
INSERT INTO cc_user.manufacturers (id, name) 
VALUES (11, 'Pip-NNC Industrial');

UPDATE cc_user.parts
SET manufacturer_id = 11
WHERE manufacturer_id IN (
    SELECT id FROM cc_user.manufacturers 
    WHERE name IN ('Pip Industrial', 'NNC Manufacturing')
);

-- Verificaciones finales
-- 1. Verificar que no hay códigos nulos o duplicados en parts
SELECT code, COUNT(*) 
FROM cc_user.parts 
GROUP BY code 
HAVING COUNT(*) > 1 OR code IS NULL;

-- 2. Verificar que no hay descripciones nulas en parts
SELECT COUNT(*) 
FROM cc_user.parts 
WHERE description IS NULL;

-- 3. Verificar precios y cantidades en reorder_options
SELECT COUNT(*) 
FROM cc_user.reorder_options 
WHERE price_usd <= 0 OR quantity <= 0 OR (price_usd/quantity NOT BETWEEN 0.02 AND 25.00);

-- 4. Verificar cantidades en locations
SELECT COUNT(*) 
FROM cc_user.locations 
WHERE qty <= 0;

-- 5. Verificar relaciones entre tablas
-- Partes sin fabricante válido (no debería haber ninguno después de la fusión)
SELECT p.id, p.code, p.manufacturer_id 
FROM cc_user.parts p
LEFT JOIN cc_user.manufacturers m ON p.manufacturer_id = m.id
WHERE m.id IS NULL;

-- Opciones de reorden sin parte válida
SELECT ro.id, ro.part_id 
FROM cc_user.reorder_options ro
LEFT JOIN cc_user.parts p ON ro.part_id = p.id
WHERE p.id IS NULL;

-- Ubicaciones sin parte válida
SELECT l.id, l.part_id 
FROM cc_user.locations l
LEFT JOIN cc_user.parts p ON l.part_id = p.id
WHERE p.id IS NULL;