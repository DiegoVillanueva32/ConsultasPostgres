-- Establecer el esquema
SET search_path = cc_user;

-- Cargar manufacturers
\copy manufacturers FROM 'manufacturers.csv' DELIMITER ',' NULL 'NULL' CSV HEADER

-- Crear tabla temporal para parts
CREATE TEMPORARY TABLE temp_parts (
    id integer,
    description character varying,
    code character varying,
    manufacturer_id integer
);

-- Cargar datos en tabla temporal
\copy temp_parts FROM 'parts.csv' DELIMITER ',' NULL 'NULL' CSV HEADER

-- Insertar en tabla real con descripción no nula
INSERT INTO parts (id, description, code, manufacturer_id)
SELECT 
    id, 
    COALESCE(description, 'Sin descripción disponible'),
    code,
    manufacturer_id
FROM temp_parts;

-- Eliminar tabla temporal
DROP TABLE temp_parts;

-- Cargar locations
\copy locations FROM 'locations.csv' DELIMITER ',' NULL 'NULL' CSV HEADER

-- Cargar reorder_options
\copy reorder_options FROM 'reorder_options.csv' DELIMITER ',' NULL 'NULL' CSV HEADER

-- Añadir restricciones FOREIGN KEY después de cargar datos
ALTER TABLE parts ADD CONSTRAINT fk_manufacturer 
FOREIGN KEY (manufacturer_id) REFERENCES manufacturers(id);

ALTER TABLE reorder_options ADD CONSTRAINT fk_part
FOREIGN KEY (part_id) REFERENCES parts(id);

ALTER TABLE locations ADD CONSTRAINT fk_part
FOREIGN KEY (part_id) REFERENCES parts(id);

-- Añadir restricciones CHECK
ALTER TABLE reorder_options ADD CHECK (price_usd > 0);
ALTER TABLE reorder_options ADD CHECK (quantity > 0);
ALTER TABLE reorder_options ADD CHECK (price_usd/quantity BETWEEN 0.02 AND 25.00);

ALTER TABLE locations ADD CHECK (qty > 0);
ALTER TABLE locations ADD UNIQUE (part_id, location);

-- Procesar fusión de fabricantes
INSERT INTO manufacturers (id, name) VALUES (11, 'Pip-NNC Industrial');

UPDATE parts
SET manufacturer_id = 11
WHERE manufacturer_id IN (
    SELECT id FROM manufacturers 
    WHERE name IN ('Pip Industrial', 'NNC Manufacturing')
);