-- 1. Creación de la tabla store con todos los campos necesarios
CREATE TABLE store (
    order_id integer,
    order_date date,
    customer_id integer,
    customer_phone varchar(12),
    customer_email text,
    item_1_id integer,
    item_1_name varchar(100),
    item_1_price numeric,
    item_2_id integer,
    item_2_name varchar(100),
    item_2_price numeric,
    item_3_id integer,
    item_3_name varchar(100),
    item_3_price numeric
);

-- 2. Inserción de todos los 100 registros en la tabla store
INSERT INTO store VALUES
(1,'2019-08-05',1,'555-555-7900','Raamiz1@email.com',33,'book shelf',200.52,NULL,NULL,NULL,NULL,NULL,NULL),
(2,'2019-08-26',2,'555-555-6934','Khoi2@email.com',42,'vacuum',231.22,NULL,NULL,NULL,NULL,NULL,NULL),
(3,'2019-08-12',3,'555-555-3698','Christopher3@email.com',48,'leather sofa',999.99,NULL,NULL,NULL,NULL,NULL,NULL),
(4,'2019-08-07',4,'555-555-6181','Daniel4@email.com',28,'camping refrigerator',199.99,NULL,NULL,NULL,NULL,NULL,NULL),
(5,'2019-08-04',5,'555-555-5099','Dillon5@email.com',32,'foot rest',80.97,NULL,NULL,NULL,NULL,NULL,NULL),
(6,'2019-08-26',6,'555-555-5920','David6@email.com',17,'chez lounge',522.12,42,'vacuum',231.22,NULL,NULL,NULL),
(7,'2019-08-08',7,'555-555-6135','Amanda7@email.com',17,'chez lounge',522.12,11,'queen mattress',401.99,38,'shower caddy',39.99),
(8,'2019-08-11',8,'555-555-5623','Sarah8@email.com',12,'king mattress',458.99,6,'bed side table',153.21,17,'chez lounge',522.12),
(9,'2019-08-31',9,'555-555-5730','Sadie9@email.com',27,'frying pan',48.99,NULL,NULL,NULL,NULL,NULL,NULL),
(10,'2019-08-08',10,'555-555-5636','Emma10@email.com',11,'queen mattress',401.99,NULL,NULL,NULL,NULL,NULL,NULL),
(11,'2019-08-20',11,'555-555-7628','Rhys11@email.com',50,'file organizer',63.99,37,'spice rack',49.99,10,'twin mattress',321.99),
(12,'2019-08-10',12,'555-555-9511','Joseph12@email.com',40,'throw blanket',149.99,44,'lawn chair',38.82,49,'small side table',150.21),
(13,'2019-08-23',13,'555-555-5635','Faaid13@email.com',39,'soap dish',10.53,37,'spice rack',49.99,NULL,NULL,NULL),
(14,'2019-08-08',14,'555-555-5280','Jiyaad14@email.com',41,'pantry jars',52.99,NULL,NULL,NULL,NULL,NULL,NULL),
(15,'2019-08-16',15,'555-555-6745','Delilah15@email.com',42,'vacuum',231.22,NULL,NULL,NULL,NULL,NULL,NULL),
(16,'2019-08-08',16,'555-555-6258','Daianee16@email.com',37,'spice rack',49.99,31,'bar stool',99.52,25,'wine glasses (set of 4)',50.52),
(17,'2019-08-08',17,'555-555-3522','Tahiyya17@email.com',6,'bed side table',153.21,NULL,NULL,NULL,NULL,NULL,NULL),
(18,'2019-08-05',18,'555-555-7468','Armando18@email.com',29,'standing desk',481.98,6,'bed side table',153.21,4,'lamp',120.98),
(19,'2019-08-02',19,'555-555-8182','Scott19@email.com',4,'lamp',120.98,NULL,NULL,NULL,NULL,NULL,NULL),
(20,'2019-08-29',20,'555-555-5840','Bodey20@email.com',20,'TV console',578.99,NULL,NULL,NULL,NULL,NULL,NULL),
(21,'2019-08-12',21,'555-555-3489','Mikaela21@email.com',34,'shelving',20.99,NULL,NULL,NULL,NULL,NULL,NULL),
(22,'2019-08-13',22,'555-555-5537','Matthew22@email.com',39,'soap dish',10.53,NULL,NULL,NULL,NULL,NULL,NULL),
(23,'2019-08-05',23,'555-555-8312','Alexandria23@email.com',24,'large area rug',549.99,18,'two-piece sectional',1200.99,NULL,NULL,NULL),
(24,'2019-08-08',24,'555-555-7365','Rueben24@email.com',29,'standing desk',481.98,29,'standing desk',481.98,34,'shelving',20.99),
(25,'2019-08-05',25,'555-555-2132','Raymond25@email.com',48,'leather sofa',999.99,NULL,NULL,NULL,NULL,NULL,NULL),
(26,'2019-08-09',26,'555-555-7907','Darius26@email.com',36,'clothing hangers',50.32,26,'dinner plates (set of 4)',54.52,NULL,NULL,NULL),
(27,'2019-08-09',27,'555-555-6305','Taamir27@email.com',45,'patio table',221.22,NULL,NULL,NULL,NULL,NULL,NULL),
(28,'2019-08-24',28,'555-555-7007','Bianca28@email.com',4,'lamp',120.98,47,'folding chair',50.52,NULL,NULL,NULL),
(29,'2019-08-22',29,'555-555-2484','Dylan29@email.com',17,'chez lounge',522.12,46,'hammock',100.53,NULL,NULL,NULL),
(30,'2019-08-18',30,'555-555-9200','Jeremiah30@email.com',17,'chez lounge',522.12,6,'bed side table',153.21,NULL,NULL,NULL),
(31,'2019-08-16',31,'555-555-4889','Anthony31@email.com',49,'small side table',150.21,NULL,NULL,NULL,NULL,NULL,NULL),
(32,'2019-08-25',32,'555-555-1812','Vincent32@email.com',23,'small area rug',349.99,NULL,NULL,NULL,NULL,NULL,NULL),
(33,'2019-08-12',33,'555-555-7914','Amy33@email.com',6,'bed side table',153.21,NULL,NULL,NULL,NULL,NULL,NULL),
(34,'2019-08-08',34,'555-555-3524','Jacob34@email.com',21,'large photo frame',42.98,13,'throw pillow set',100.22,NULL,NULL,NULL),
(35,'2019-08-22',35,'555-555-1507','Erin35@email.com',20,'TV console',578.99,NULL,NULL,NULL,NULL,NULL,NULL),
(36,'2019-08-28',36,'555-555-8360','Marco36@email.com',47,'folding chair',50.52,NULL,NULL,NULL,NULL,NULL,NULL),
(37,'2019-08-19',37,'555-555-9485','Brian37@email.com',45,'patio table',221.22,11,'queen mattress',401.99,NULL,NULL,NULL),
(38,'2019-08-06',38,'555-555-1293','Shaafia38@email.com',30,'bar cart',327.51,NULL,NULL,NULL,NULL,NULL,NULL),
(39,'2019-08-08',39,'555-555-1623','Guem39@email.com',29,'standing desk',481.98,9,'twin bed frame',339.42,31,'bar stool',99.52),
(40,'2019-08-15',40,'555-555-3391','Bakar40@email.com',51,'curtains',89.99,13,'throw pillow set',100.22,22,'small photo frame',22.98),
(41,'2019-08-10',41,'555-555-4104','Eleanore41@email.com',46,'hammock',100.53,21,'large photo frame',42.98,49,'small side table',150.21),
(42,'2019-08-11',42,'555-555-8129','Mark42@email.com',39,'soap dish',10.53,NULL,NULL,NULL,NULL,NULL,NULL),
(43,'2019-08-29',43,'555-555-6684','Tiffany43@email.com',1,'king bed frame',500.42,12,'king mattress',458.99,24,'large area rug',549.99),
(44,'2019-08-23',44,'555-555-2964','Dayna44@email.com',26,'dinner plates (set of 4)',54.52,8,'queen bed frame',421.42,NULL,NULL,NULL),
(45,'2019-08-03',45,'555-555-3157','Marcus45@email.com',12,'king mattress',458.99,34,'shelving',20.99,6,'bed side table',153.21),
(46,'2019-08-30',46,'555-555-5351','Michelle46@email.com',9,'twin bed frame',339.42,28,'camping refrigerator',199.99,NULL,NULL,NULL),
(47,'2019-08-31',47,'555-555-4762','Saul47@email.com',27,'frying pan',48.99,42,'vacuum',231.22,NULL,NULL,NULL),
(48,'2019-08-05',48,'555-555-7443','Caswyn48@email.com',39,'soap dish',10.53,NULL,NULL,NULL,NULL,NULL,NULL),
(49,'2019-08-23',49,'555-555-1495','Lennon49@email.com',6,'bed side table',153.21,14,'coffee table',200.41,16,'recliner',823.44),
(50,'2019-08-22',50,'555-555-7003','Zameel50@email.com',33,'book shelf',200.52,10,'twin mattress',321.99,NULL,NULL,NULL),
(51,'2019-08-08',51,'555-555-7818','Amaanullah51@email.com',4,'lamp',120.98,38,'shower caddy',39.99,31,'bar stool',99.52),
(52,'2019-08-10',52,'555-555-9121','Zakary52@email.com',39,'soap dish',10.53,27,'frying pan',48.99,NULL,NULL,NULL),
(53,'2019-08-04',53,'555-555-7418','Kyna53@email.com',49,'small side table',150.21,18,'two-piece sectional',1200.99,NULL,NULL,NULL),
(54,'2019-08-01',54,'555-555-5863','Maxwell54@email.com',3,'dining table',349.99,NULL,NULL,NULL,NULL,NULL,NULL),
(55,'2019-08-19',55,'555-555-7632','Aneesa55@email.com',9,'twin bed frame',339.42,1,'king bed frame',500.42,26,'dinner plates (set of 4)',54.52),
(56,'2019-08-06',56,'555-555-5720','Mckinsey56@email.com',9,'twin bed frame',339.42,NULL,NULL,NULL,NULL,NULL,NULL),
(57,'2019-08-20',57,'555-555-4811','Erin57@email.com',48,'leather sofa',999.99,NULL,NULL,NULL,NULL,NULL,NULL),
(58,'2019-08-25',58,'555-555-5865','Nicole58@email.com',34,'shelving',20.99,10,'twin mattress',321.99,NULL,NULL,NULL),
(59,'2019-08-26',59,'555-555-2909','Najaat59@email.com',3,'dining table',349.99,NULL,NULL,NULL,NULL,NULL,NULL),
(60,'2019-08-13',60,'555-555-8241','David60@email.com',28,'camping refrigerator',199.99,40,'throw blanket',149.99,NULL,NULL,NULL),
(61,'2019-08-07',61,'555-555-7075','Morgan61@email.com',47,'folding chair',50.52,4,'lamp',120.98,13,'throw pillow set',100.22),
(62,'2019-08-26',62,'555-555-7806','Anthony62@email.com',27,'frying pan',48.99,NULL,NULL,NULL,NULL,NULL,NULL),
(63,'2019-08-01',63,'555-555-7260','Brittany63@email.com',9,'twin bed frame',339.42,3,'dining table',349.99,NULL,NULL,NULL),
(64,'2019-08-09',64,'555-555-3149','Jacob64@email.com',2,'loveseat',829.99,NULL,NULL,NULL,NULL,NULL,NULL),
(65,'2019-08-17',65,'555-555-6366','Talha65@email.com',31,'bar stool',99.52,43,'mirror',100.42,9,'twin bed frame',339.42),
(66,'2019-08-09',66,'555-555-2891','James66@email.com',30,'bar cart',327.51,NULL,NULL,NULL,NULL,NULL,NULL),
(67,'2019-08-05',67,'555-555-8843','Flora67@email.com',45,'patio table',221.22,17,'chez lounge',522.12,NULL,NULL,NULL),
(68,'2019-08-18',68,'555-555-5697','Daniel68@email.com',30,'bar cart',327.51,3,'dining table',349.99,30,'bar cart',327.51),
(69,'2019-08-06',69,'555-555-4962','Damion69@email.com',48,'leather sofa',999.99,NULL,NULL,NULL,NULL,NULL,NULL),
(70,'2019-08-29',70,'555-555-7296','Summer70@email.com',11,'queen mattress',401.99,NULL,NULL,NULL,NULL,NULL,NULL),
(71,'2019-08-31',71,'555-555-6868','Kainalu71@email.com',16,'recliner',823.44,NULL,NULL,NULL,NULL,NULL,NULL),
(72,'2019-08-08',72,'555-555-6336','Zachary72@email.com',22,'small photo frame',22.98,50,'file organizer',63.99,17,'chez lounge',522.12),
(73,'2019-08-11',73,'555-555-8375','Rebecca73@email.com',10,'twin mattress',321.99,NULL,NULL,NULL,NULL,NULL,NULL),
(74,'2019-08-10',74,'555-555-5930','Alan74@email.com',6,'bed side table',153.21,NULL,NULL,NULL,NULL,NULL,NULL),
(75,'2019-08-04',75,'555-555-1372','Uqbah75@email.com',12,'king mattress',458.99,NULL,NULL,NULL,NULL,NULL,NULL),
(76,'2019-08-14',76,'555-555-8689','Aasiya76@email.com',10,'twin mattress',321.99,NULL,NULL,NULL,NULL,NULL,NULL),
(77,'2019-08-09',77,'555-555-6597','AbdulHai77@email.com',13,'throw pillow set',100.22,NULL,NULL,NULL,NULL,NULL,NULL),
(78,'2019-08-03',78,'555-555-5908','Tabitha78@email.com',31,'bar stool',99.52,NULL,NULL,NULL,NULL,NULL,NULL),
(79,'2019-08-04',79,'555-555-5145','Kathryn79@email.com',34,'shelving',20.99,43,'mirror',100.42,NULL,NULL,NULL),
(80,'2019-08-12',80,'555-555-7266','Alyssa80@email.com',5,'chair',51.33,51,'curtains',89.99,NULL,NULL,NULL),
(81,'2019-08-18',1,'555-555-7900','Raamiz1@email.com',13,'throw pillow set',100.22,35,'storage box',25.99,NULL,NULL,NULL),
(82,'2019-08-17',2,'555-555-6934','Khoi2@email.com',18,'two-piece sectional',1200.99,NULL,NULL,NULL,NULL,NULL,NULL),
(83,'2019-08-16',3,'555-555-3698','Christopher3@email.com',42,'vacuum',231.22,NULL,NULL,NULL,NULL,NULL,NULL),
(84,'2019-08-04',4,'555-555-6181','Daniel4@email.com',28,'camping refrigerator',199.99,11,'queen mattress',401.99,34,'shelving',20.99),
(85,'2019-08-06',5,'555-555-5099','Dillon5@email.com',13,'throw pillow set',100.22,NULL,NULL,NULL,NULL,NULL,NULL),
(86,'2019-08-01',6,'555-555-5920','David6@email.com',30,'bar cart',327.51,43,'mirror',100.42,NULL,NULL,NULL),
(87,'2019-08-13',7,'555-555-6135','Amanda7@email.com',9,'twin bed frame',339.42,38,'shower caddy',39.99,5,'chair',51.33),
(88,'2019-08-02',8,'555-555-5623','Sarah8@email.com',43,'mirror',100.42,5,'chair',51.33,46,'hammock',100.53),
(89,'2019-08-21',9,'555-555-5730','Sadie9@email.com',32,'foot rest',80.97,NULL,NULL,NULL,NULL,NULL,NULL),
(90,'2019-08-02',10,'555-555-5636','Emma10@email.com',41,'pantry jars',52.99,27,'frying pan',48.99,NULL,NULL,NULL),
(91,'2019-08-24',11,'555-555-7628','Rhys11@email.com',15,'desk',322.99,NULL,NULL,NULL,NULL,NULL,NULL),
(92,'2019-08-23',12,'555-555-9511','Joseph12@email.com',7,'armoir',555.98,NULL,NULL,NULL,NULL,NULL,NULL),
(93,'2019-08-07',13,'555-555-5635','Faaid13@email.com',8,'queen bed frame',421.42,8,'queen bed frame',421.42,27,'frying pan',48.99),
(94,'2019-08-10',14,'555-555-5280','Jiyaad14@email.com',26,'dinner plates (set of 4)',54.52,NULL,NULL,NULL,NULL,NULL,NULL),
(95,'2019-08-06',15,'555-555-6745','Delilah15@email.com',20,'TV console',578.99,NULL,NULL,NULL,NULL,NULL,NULL),
(96,'2019-08-14',16,'555-555-6258','Daianee16@email.com',16,'recliner',823.44,NULL,NULL,NULL,NULL,NULL,NULL),
(97,'2019-08-19',17,'555-555-3522','Tahiyya17@email.com',31,'bar stool',99.52,31,'bar stool',99.52,43,'mirror',100.42),
(98,'2019-08-15',18,'555-555-7468','Armando18@email.com',40,'throw blanket',149.99,2,'loveseat',829.99,31,'bar stool',99.52),
(99,'2019-08-01',19,'555-555-8182','Scott19@email.com',6,'bed side table',153.21,NULL,NULL,NULL,NULL,NULL,NULL),
(100,'2019-08-10',20,'555-555-5840','Bodey20@email.com',21,'large photo frame',42.98,36,'clothing hangers',50.32,NULL,NULL,NULL);

-- 3. Verificación de la tabla store
SELECT * FROM store LIMIT 10;

-- 4. Consultas iniciales de inspección
-- Contar órdenes distintas
SELECT COUNT(DISTINCT order_id) AS total_orders FROM store;

-- Contar clientes distintos
SELECT COUNT(DISTINCT customer_id) AS total_customers FROM store;

-- Ver datos del cliente con ID 1
SELECT customer_id, customer_email, customer_phone 
FROM store 
WHERE customer_id = 1;

-- Contar órdenes del cliente 1
SELECT COUNT(*) AS orders_from_customer_1
FROM store 
WHERE customer_id = 1;

-- Ver datos del item con ID 4
SELECT item_1_id, item_1_name, item_1_price 
FROM store 
WHERE item_1_id = 4;

-- Contar cuántas veces aparece el item 4 como item_1
SELECT COUNT(*) AS item_4_as_item1_count
FROM store 
WHERE item_1_id = 4;

-- 5. Normalización de la base de datos

-- Crear tabla customers
CREATE TABLE customers AS
SELECT DISTINCT customer_id, customer_phone, customer_email
FROM store;

-- Establecer customer_id como clave primaria en customers
ALTER TABLE customers
ADD PRIMARY KEY (customer_id);

-- Crear tabla items (combinando todos los items)
CREATE TABLE items AS
SELECT DISTINCT item_1_id AS item_id, item_1_name AS item_name, item_1_price AS item_price
FROM store WHERE item_1_id IS NOT NULL
UNION
SELECT DISTINCT item_2_id AS item_id, item_2_name AS item_name, item_2_price AS item_price
FROM store WHERE item_2_id IS NOT NULL
UNION
SELECT DISTINCT item_3_id AS item_id, item_3_name AS item_name, item_3_price AS item_price
FROM store WHERE item_3_id IS NOT NULL
ORDER BY item_id;

-- Establecer item_id como clave primaria en items
ALTER TABLE items
ADD PRIMARY KEY (item_id);

-- Crear tabla orders
CREATE TABLE orders AS
SELECT DISTINCT order_id, order_date, customer_id
FROM store
ORDER BY order_id;

-- Establecer order_id como clave primaria en orders
ALTER TABLE orders
ADD PRIMARY KEY (order_id);

-- Crear tabla orders_items (relación muchos-a-muchos)
CREATE TABLE orders_items AS
SELECT order_id, item_1_id AS item_id FROM store WHERE item_1_id IS NOT NULL
UNION ALL
SELECT order_id, item_2_id AS item_id FROM store WHERE item_2_id IS NOT NULL
UNION ALL
SELECT order_id, item_3_id AS item_id FROM store WHERE item_3_id IS NOT NULL
ORDER BY order_id, item_id;

-- Establecer claves foráneas
ALTER TABLE orders
ADD FOREIGN KEY (customer_id) REFERENCES customers(customer_id);

ALTER TABLE orders_items
ADD FOREIGN KEY (item_id) REFERENCES items(item_id);

ALTER TABLE orders_items
ADD FOREIGN KEY (order_id) REFERENCES orders(order_id);

-- 6. Consultas comparativas entre la estructura original y normalizada

-- Consulta 14: Emails de clientes con órdenes después del 25 de julio (estructura original)
SELECT DISTINCT customer_email 
FROM store 
WHERE order_date > '2019-07-25'
ORDER BY customer_email;

-- Consulta 15: Emails de clientes con órdenes después del 25 de julio (estructura normalizada)
SELECT DISTINCT c.customer_email
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
WHERE o.order_date > '2019-07-25'
ORDER BY c.customer_email;

-- Consulta 16: Número de órdenes por item (estructura original)
WITH all_items AS (
    SELECT item_1_id AS item_id FROM store WHERE item_1_id IS NOT NULL
    UNION ALL
    SELECT item_2_id AS item_id FROM store WHERE item_2_id IS NOT NULL
    UNION ALL
    SELECT item_3_id AS item_id FROM store WHERE item_3_id IS NOT NULL
)
SELECT i.item_id, i.item_name, COUNT(ai.item_id) AS order_count
FROM all_items ai
JOIN items i ON ai.item_id = i.item_id
GROUP BY i.item_id, i.item_name
ORDER BY order_count DESC;

-- Consulta 17: Número de órdenes por item (estructura normalizada)
SELECT i.item_id, i.item_name, COUNT(oi.item_id) AS order_count
FROM orders_items oi
JOIN items i ON oi.item_id = i.item_id
GROUP BY i.item_id, i.item_name
ORDER BY order_count DESC;

-- 7. Consultas adicionales

-- Clientes con más de una orden y sus emails
SELECT c.customer_id, c.customer_email, COUNT(o.order_id) AS order_count
FROM customers c
JOIN orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.customer_email
HAVING COUNT(o.order_id) > 1
ORDER BY order_count DESC;

-- Órdenes después del 15 de julio que incluyen una lámpara
SELECT COUNT(DISTINCT o.order_id) AS lamp_orders_after_july15
FROM orders o
JOIN orders_items oi ON o.order_id = oi.order_id
JOIN items i ON oi.item_id = i.item_id
WHERE o.order_date > '2019-07-15' 
AND i.item_name LIKE '%lamp%';

-- Órdenes que incluyen una silla
SELECT COUNT(DISTINCT o.order_id) AS chair_orders
FROM orders o
JOIN orders_items oi ON o.order_id = oi.order_id
JOIN items i ON oi.item_id = i.item_id
WHERE i.item_name LIKE '%chair%';

-- 8. Consulta para verificar la integridad de los datos normalizados
SELECT 
    (SELECT COUNT(DISTINCT order_id) FROM store) AS original_orders,
    (SELECT COUNT(*) FROM orders) AS normalized_orders,
    (SELECT COUNT(DISTINCT customer_id) FROM store) AS original_customers,
    (SELECT COUNT(*) FROM customers) AS normalized_customers,
    (SELECT COUNT(DISTINCT item_1_id) + 
     COUNT(DISTINCT item_2_id) + 
     COUNT(DISTINCT item_3_id) - 
     COUNT(DISTINCT CASE WHEN item_1_id = item_2_id OR item_1_id = item_3_id OR item_2_id = item_3_id THEN item_1_id END)
     FROM store WHERE item_1_id IS NOT NULL OR item_2_id IS NOT NULL OR item_3_id IS NOT NULL) AS original_items,
    (SELECT COUNT(*) FROM items) AS normalized_items;